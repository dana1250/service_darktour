package darktour;

public class historic_info {
	int HISTORIC_NUM;
	double LATITUDE;
	double LONGITUDE;
	String NAME;
	String INCIDENT;
	String EXPLAIN_HIS;
	String ADDRESS;
	String HIS_SOURCE;
	String HIS_IMAGE;
	int COUNT_HISTORIC;
	public int getHISTORIC_NUM() {
		return HISTORIC_NUM;
	}
	public void setHISTORIC_NUM(int hISTORIC_NUM) {
		HISTORIC_NUM = hISTORIC_NUM;
	}
	public double getLATITUDE() {
		return LATITUDE;
	}
	public void setLATITUDE(double lATITUDE) {
		LATITUDE = lATITUDE;
	}
	public double getLONGITUDE() {
		return LONGITUDE;
	}
	public void setLONGITUDE(double lONGITUDE) {
		LONGITUDE = lONGITUDE;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getINCIDENT() {
		return INCIDENT;
	}
	public void setINCIDENT(String iNCIDENT) {
		INCIDENT = iNCIDENT;
	}
	public String getEXPLAIN_HIS() {
		return EXPLAIN_HIS;
	}
	public void setEXPLAIN_HIS(String eXPLAIN_HIS) {
		EXPLAIN_HIS = eXPLAIN_HIS;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public String getHIS_SOURCE() {
		return HIS_SOURCE;
	}
	public void setHIS_SOURCE(String hIS_SOURCE) {
		HIS_SOURCE = hIS_SOURCE;
	}
	public String getHIS_IMAGE() {
		return HIS_IMAGE;
	}
	public void setHIS_IMAGE(String hIS_IMAGE) {
		HIS_IMAGE = hIS_IMAGE;
	}
	public int getCOUNT_HISTORIC() {
		return COUNT_HISTORIC;
	}
	public void setCOUNT_HISTORIC(int cOUNT_HISTORIC) {
		COUNT_HISTORIC = cOUNT_HISTORIC;
	}
}