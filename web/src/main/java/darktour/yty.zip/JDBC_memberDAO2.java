package darktour;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
 
import darktour.MemberVO;
 
public class JDBC_memberDAO2 {
 
    /**
     * �ʿ��� property ����
     */
    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
   
    //MySQL
    String driverName="com.mysql.jdbc.Driver";
    String url = "jdbc:mysql://localhost:3306/darktour";
 

    String id = "root";
    String pwd ="0797";
   
    /**
     * �ε�� ������ ���� ������ �ۼ�
     */
    public JDBC_memberDAO2(){
       
        try {
            //�ε�
            Class.forName(driverName);
           
            //����
            con = DriverManager.getConnection(url,id,pwd);      
           
        } catch (ClassNotFoundException e) {
           
            System.out.println(e+"=> �ε� ����");
           
        } catch (SQLException e) {
           
            System.out.println(e+"=> ���� ����");
        }
    }//JDBC_memberDAO()
   
    /**
     * DB�ݱ� ��� �޼ҵ� �ۼ�
     */
    public void db_close(){
       
        try {
           
            if (rs != null ) rs.close();
            if (ps != null ) ps.close();      
            if (st != null ) st.close();
       
        } catch (SQLException e) {
            System.out.println(e+"=> �ݱ� ����");
        }      
       
    } //db_close
   
    /**
     * member���̺��� insert�ϴ� �޼ҵ� �ۼ�
     */
    public int memberInsert(MemberVO vo){
        int result = 0;
       
        try{
        //����
            String sql = "INSERT INTO users VALUES(?,?,?,?)";
           
            ps = con.prepareStatement(sql);
            ps.setString(1, vo.getNAME());
            ps.setString(2, vo.getUSER_ID());
            ps.setString(3, vo.getUSER_PWD());
            ps.setString(4, vo.getFAVORITE_HIS());

            result = ps.executeUpdate();
           
        }catch (Exception e){
           
            System.out.println(e + "=> memberInsert fail");
           
        }finally{
            db_close();
        }
       
        return result;
    }//memberInsert
   
    /**
     * member���̺��� ��� ���ڵ� �˻���(Select)�� �޼��� �ۼ�
     */   
    public ArrayList<MemberVO> getMemberlist(){
       
        ArrayList<MemberVO> list = new ArrayList<MemberVO>();
       
        try{//����
            st = con.createStatement();
            rs = st.executeQuery("select * from users");
           
            while(rs.next()){
                MemberVO vo = new MemberVO();
               
                vo.setNAME(rs.getString(1));
                vo.setUSER_ID(rs.getString(2));
                vo.setUSER_PWD(rs.getString(3));
                vo.setFAVORITE_HIS(rs.getString(4));
               
                list.add(vo);
            }
        }catch(Exception e){          
            System.out.println(e+"=> getMemberlist fail");        
        }finally{          
            db_close();
        }      
        return list;
    }//getMemberlist
    
    public int delMemberlist(String id){
        int result = 0;
        try{//����
           
            ps = con.prepareStatement("delete from users where USER_ID = ?");
            //?������ŭ �� ����
            ps.setString(1, id.trim());
            result = ps.executeUpdate(); //������������ ������ ���ڵ� �� ��ȯ       
               
        }catch(Exception e){           
            System.out.println(e+"=> delMemberlist fail");         
        }finally{          
            db_close();
        }      
       
        return result;
    }  
}